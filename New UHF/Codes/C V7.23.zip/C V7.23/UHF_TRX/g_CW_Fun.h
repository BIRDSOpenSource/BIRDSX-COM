int CW_PIN = PA12;

//___character_space_function___///////////////////////////////////
void CH_SPACE()
{
   digitalWrite(CW_PIN,LOW);
   digitalWrite(SW_3V     ,LOW  );
   delay(180);  
}

//___Word_space_function___////////////////////////////////////////
void WORD_SPACE()
{
   digitalWrite(CW_PIN,LOW) ;
   digitalWrite(SW_3V     ,LOW  );
   delay(420); 
}

//___dit_function___///////////////////////////////////////////////
void DIT()
{
   digitalWrite(CW_PIN,HIGH);
   digitalWrite(SW_3V     ,HIGH  );
   delay(60);
   digitalWrite(CW_PIN,LOW);
   digitalWrite(SW_3V     ,LOW  );
   delay(60);
}

//___dit_function___///////////////////////////////////////////////
void DAH()
{
   digitalWrite(CW_PIN,HIGH);
   digitalWrite(SW_3V     ,HIGH  );
   delay(180);
   digitalWrite(CW_PIN,LOW);
   digitalWrite(SW_3V     ,LOW  );
   delay(60);
}

void CW_A() { DIT(); DAH();               CH_SPACE(); }
void CW_B() { DAH(); DIT(); DIT(); DIT(); CH_SPACE(); }
void CW_C() { DAH(); DIT(); DAH(); DIT(); CH_SPACE(); }
void CW_D() { DAH(); DIT(); DIT();        CH_SPACE(); }
void CW_E() { DIT();                      CH_SPACE(); }
void CW_F() { DIT(); DIT(); DAH(); DIT(); CH_SPACE(); }
void CW_G() { DAH(); DAH(); DIT();        CH_SPACE(); }
void CW_H() { DIT(); DIT(); DIT(); DIT(); CH_SPACE(); }
void CW_I() { DIT(); DIT();               CH_SPACE(); }
void CW_J() { DIT(); DAH(); DAH(); DAH(); CH_SPACE(); }
void CW_K() { DAH(); DIT(); DAH();        CH_SPACE(); }
void CW_L() { DIT(); DAH(); DIT(); DIT(); CH_SPACE(); }
void CW_M() { DAH(); DAH();               CH_SPACE(); }
void CW_N() { DAH(); DIT();               CH_SPACE(); }
void CW_O() { DAH(); DAH(); DAH();        CH_SPACE(); }
void CW_P() { DIT(); DAH(); DAH(); DIT(); CH_SPACE(); }
void CW_Q() { DAH(); DAH(); DIT(); DAH(); CH_SPACE(); }
void CW_R() { DIT(); DAH(); DIT();        CH_SPACE(); }
void CW_S() { DIT(); DIT(); DIT();        CH_SPACE(); }
void CW_T() { DAH();                      CH_SPACE(); }
void CW_U() { DIT(); DIT(); DAH();        CH_SPACE(); }
void CW_V() { DIT(); DIT(); DIT(); DAH(); CH_SPACE(); }
void CW_W() { DIT(); DAH(); DAH();        CH_SPACE(); }
void CW_X() { DAH(); DIT(); DIT(); DAH(); CH_SPACE(); }
void CW_Y() { DAH(); DIT(); DAH(); DAH(); CH_SPACE(); }
void CW_Z() { DAH(); DAH(); DIT(); DIT(); CH_SPACE(); }

// Numbers morse code  
void CW_0() { DAH(); DAH(); DAH(); DAH(); DAH(); CH_SPACE(); }
void CW_1() { DIT(); DAH(); DAH(); DAH(); DAH(); CH_SPACE(); }
void CW_2() { DIT(); DIT(); DAH(); DAH(); DAH(); CH_SPACE(); }
void CW_3() { DIT(); DIT(); DIT(); DAH(); DAH(); CH_SPACE(); }
void CW_4() { DIT(); DIT(); DIT(); DIT(); DAH(); CH_SPACE(); }
void CW_5() { DIT(); DIT(); DIT(); DIT(); DIT(); CH_SPACE(); }
void CW_6() { DAH(); DIT(); DIT(); DIT(); DIT(); CH_SPACE(); }
void CW_7() { DAH(); DAH(); DIT(); DIT(); DIT(); CH_SPACE(); }
void CW_8() { DAH(); DAH(); DAH(); DIT(); DIT(); CH_SPACE(); }
void CW_9() { DAH(); DAH(); DAH(); DAH(); DIT(); CH_SPACE(); }


void CW_SPATIUM2()
{
   CW_S();
   CW_P();
   CW_A();
   CW_T();
   CW_I();
   CW_U();
   CW_M();
   CW_2();
   return;
}

void CW_LETTER(uint8_t CWL)
{
   //Hexa decimal values
        if(CWL == 0x00||CWL ==0x30) CW_0();
   else if(CWL == 0x01||CWL ==0x31) CW_1();
   else if(CWL == 0x02||CWL ==0x32) CW_2();
   else if(CWL == 0x03||CWL ==0x33) CW_3();
   else if(CWL == 0x04||CWL ==0x34) CW_4();
   else if(CWL == 0x05||CWL ==0x35) CW_5();
   else if(CWL == 0x06||CWL ==0x36) CW_6();
   else if(CWL == 0x07||CWL ==0x37) CW_7();
   else if(CWL == 0x08||CWL ==0x38) CW_8();
   else if(CWL == 0x09||CWL ==0x39) CW_9();
   else if(CWL == 0x0A||CWL ==0x61||CWL ==0x41) CW_A();
   else if(CWL == 0x0B||CWL ==0x62||CWL ==0x42) CW_B();
   else if(CWL == 0x0C||CWL ==0x63||CWL ==0x43) CW_C();
   else if(CWL == 0x0D||CWL ==0x64||CWL ==0x44) CW_D();
   else if(CWL == 0x0E||CWL ==0x65||CWL ==0x45) CW_E();
   else if(CWL == 0x0F||CWL ==0x66||CWL ==0x46) CW_F();
   //-------------------------
   
   //normal ascii for CW mission
   else if(CWL == 0x67||CWL ==0x47) CW_G();
   else if(CWL == 0x68||CWL ==0x48) CW_H();
   else if(CWL == 0x69||CWL ==0x49) CW_I();
   else if(CWL == 0x6a||CWL ==0x4a) CW_J();
   else if(CWL == 0x6b||CWL ==0x4b) CW_K();
   else if(CWL == 0x6c||CWL ==0x4c) CW_L();
   else if(CWL == 0x6d||CWL ==0x4d) CW_M();
   else if(CWL == 0x6e||CWL ==0x4e) CW_N();
   else if(CWL == 0x6f||CWL ==0x4f) CW_O();
   else if(CWL == 0x70||CWL ==0x50) CW_P();
   else if(CWL == 0x71||CWL ==0x51) CW_Q();
   else if(CWL == 0x72||CWL ==0x52) CW_R();
   else if(CWL == 0x73||CWL ==0x53) CW_S();
   else if(CWL == 0x74||CWL ==0x54) CW_T();
   else if(CWL == 0x75||CWL ==0x55) CW_U();
   else if(CWL == 0x76||CWL ==0x56) CW_V();
   else if(CWL == 0x77||CWL ==0x57) CW_W();
   else if(CWL == 0x78||CWL ==0x58) CW_X();
   else if(CWL == 0x79||CWL ==0x59) CW_Y();
   else if(CWL == 0x7a||CWL ==0x6a) CW_Z();

   else if(CWL == 0xAA) WORD_SPACE();  
}

void Send_CW_MSG(char *daray)
{
  int daray_size = strlen(daray) ;
  Serial.println(daray_size,DEC);
  
  for(int i=0; i<daray_size; i++)
  {
    CW_LETTER(daray[i]);
    Serial.print(daray[i]);
    //delay(400);
  }
  Serial.println();
}
