#include "SX1278Lib.h"
#include <SPI.h>

SX1278Lib::SX1278Lib(int cs) 
{
  _cs = cs;
  pinMode(_cs, OUTPUT);
}

void SX1278Lib::SPItransfer(uint8_t cmd, uint8_t reg, uint8_t* dataOut, uint8_t* dataIn, uint8_t numBytes) 
{
  // pull CS low
  digitalWrite(_cs, LOW);
  // send SPI register address with access command
  SPI.transfer(reg | cmd);
  // send data or get response
  if(cmd == SPIwriteCommand) 
  {
    if(dataOut != NULL) 
    {
      for(size_t n = 0; n < numBytes; n++) 
      {
        SPI.transfer(dataOut[n]);
      }
    }
  } 
  
  else if (cmd == SPIreadCommand) 
  {
    if(dataIn != NULL) 
    {
      for(size_t n = 0; n < numBytes; n++) 
      {
        dataIn[n] = SPI.transfer(0x00);
      }
    }
  }
  // release CS
  digitalWrite(_cs, HIGH);
}

void SX1278Lib::SPIwriteRegister(uint8_t reg, uint8_t data) 
{
  SPItransfer(SPIwriteCommand, reg, &data, NULL, 1);
}

void SX1278Lib::SPIwriteRegisterBurst(uint8_t reg, uint8_t* data, uint8_t numBytes) 
{
  SPItransfer(SPIwriteCommand, reg, data, NULL, numBytes);
}

uint8_t SX1278Lib::SPIreadRegister(uint8_t reg) 
{
  uint8_t resp = 0;
  SPItransfer(SPIreadCommand, reg, NULL, &resp, 1);
  return(resp);
}

void SX1278Lib::SPIreadRegisterBurst(uint8_t reg, uint8_t numBytes, uint8_t* inBytes) 
{
  SPItransfer(SPIreadCommand, reg, NULL, inBytes, numBytes);
}

int16_t SX1278Lib::SPIgetRegValue(uint8_t reg, uint8_t msb , uint8_t lsb )
{
  if((msb > 7) || (lsb > 7) || (lsb > msb)) 
  {
    return(ERR_INVALID_BIT_RANGE);
  }

  uint8_t rawValue = SPIreadRegister(reg);
  uint8_t maskedValue = rawValue & ((0b11111111 << lsb) & (0b11111111 >> (7 - msb)));
  return(maskedValue);
}

int16_t SX1278Lib::SPIsetRegValue(uint8_t reg, uint8_t value, uint8_t msb , uint8_t lsb, uint8_t checkInterval, uint8_t checkMask)
{
  if((msb > 7) || (lsb > 7) || (lsb > msb)) 
  {
    return(ERR_INVALID_BIT_RANGE);
  }

  uint8_t currentValue = SPIreadRegister(reg);
  uint8_t mask = ~((0b11111111 << (msb + 1)) | (0b11111111 >> (8 - lsb)));
  uint8_t newValue = (currentValue & ~mask) | (value & mask);
  SPIwriteRegister(reg, newValue);

  uint32_t start = micros();
  uint8_t readValue = 0x00;
  
  while(micros() - start < (checkInterval * 1000)) 
  {
    readValue = SPIreadRegister(reg);
    
    if((readValue & checkMask) == (newValue & checkMask)) 
    {
        // check passed, we can stop the loop
        return(ERR_NONE);
    }
  }

  return(ERR_SPI_WRITE_FAILED);

}

int16_t SX1278Lib::getActiveModem() 
{
  return(SPIgetRegValue(SX127X_REG_OP_MODE, 7, 7));
}

int16_t SX1278Lib::setMode(uint8_t mode) 
{
  uint8_t checkMask = 0xFF;
  if((getActiveModem() == SX127X_FSK_OOK) && (mode == SX127X_RX)) 
  {
    // disable checking of RX bit in FSK RX mode, as it sometimes seem to fail (#276)
    checkMask = 0xFE;
  }
  return(SPIsetRegValue(SX127X_REG_OP_MODE, mode, 2, 0, 5, checkMask));
}

int16_t SX1278Lib::standby() 
{
  // set mode to standby
  return(setMode(SX127X_STANDBY));
}

int16_t SX1278Lib::setActiveModem(uint8_t modem) 
{
  // set mode to SLEEP
  int16_t state = setMode(SX127X_SLEEP);

  // set modem
  state |= SPIsetRegValue(SX127X_REG_OP_MODE, modem, 7, 7, 5);

  // set mode to STANDBY
  state |= setMode(SX127X_STANDBY);
  return(state);
}

int16_t SX1278Lib::setAFCAGCTrigger(uint8_t trigger) 
{
  if(getActiveModem() != SX127X_FSK_OOK) 
  {
    return(ERR_WRONG_MODEM);
  }

  //set AFC&AGC trigger
  SPIsetRegValue(SX127X_REG_RX_CONFIG, 0, 3, 3);
  SPIsetRegValue(SX127X_REG_RX_CONFIG, 1, 6, 6);
  return(SPIsetRegValue(SX127X_REG_RX_CONFIG, 1, 2, 0));  
}

int16_t SX1278Lib::setOOK(bool enableOOK) 
{
  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK) 
  {
    return(ERR_WRONG_MODEM);
  }

  // set OOK and if successful, save the new setting
  int16_t state = ERR_NONE;
  if(enableOOK) 
  {
    state = SPIsetRegValue(SX127X_REG_OP_MODE, SX127X_MODULATION_OOK, 6, 5, 5);
    state |= setAFCAGCTrigger(SX127X_RX_TRIGGER_RSSI_INTERRUPT);
  } 
  else 
  {
    state = SPIsetRegValue(SX127X_REG_OP_MODE, SX127X_MODULATION_FSK, 6, 5, 5);
    state |= setAFCAGCTrigger(SX127X_RX_TRIGGER_BOTH);
  }
  if(state == ERR_NONE) 
  {
    _ook = enableOOK;
  }

  return(state);
}

int16_t SX1278Lib::setBitRate(float br) 
{
  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK) 
  {
    return(ERR_WRONG_MODEM);
  }

  // check allowed bit rate
  if(_ook) 
  {
    CHECK_RANGE(br, 1.2, 32.768002, ERR_INVALID_BIT_RATE);      // Found that 32.768 is 32.768002
  } 
  else 
  {
    CHECK_RANGE(br, 1.2, 300.0, ERR_INVALID_BIT_RATE);
  }

  // set mode to STANDBY
  int16_t state = setMode(SX127X_STANDBY);

  // set bit rate
  uint16_t bitRate = (SX127X_CRYSTAL_FREQ * 1000.0) / br;
  state  = SPIsetRegValue(SX127X_REG_BITRATE_MSB, (bitRate & 0xFF00) >> 8, 7, 0);
  state |= SPIsetRegValue(SX127X_REG_BITRATE_LSB,  bitRate & 0x00FF, 7, 0);

  /// \todo fractional part of bit rate setting (not in OOK)
  if(state == ERR_NONE) 
  {
    _br = br;
  }
  return(state);
}

int16_t SX1278Lib::setFrequencyDeviation(float freqDev) 
{
  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK) 
  {
    return(ERR_WRONG_MODEM);
  }

  // set frequency deviation to lowest available setting (required for digimodes)
  float newFreqDev = freqDev;
  if(freqDev < 0.0) 
  {
    newFreqDev = 0.6;
  }

  // check frequency deviation range
  if(!((newFreqDev + _br/2.0 <= 250.0) && (freqDev <= 200.0))) 
  {
    return(ERR_INVALID_FREQUENCY_DEVIATION);
  }

  // set mode to STANDBY
  int16_t state = setMode(SX127X_STANDBY);

  // set allowed frequency deviation
  uint32_t base = 1;
  uint32_t FDEV = (newFreqDev * (base << 19)) / 32000;
  state = SPIsetRegValue(SX127X_REG_FDEV_MSB, (FDEV & 0xFF00) >> 8, 5, 0);
  state |= SPIsetRegValue(SX127X_REG_FDEV_LSB, FDEV & 0x00FF, 7, 0);
  return(state);
}

//uint8_t SX1278Lib::calculateBWManExp(float bandwidth)
//{
//  for(uint8_t e = 7; e >= 1; e--) 
//  {
//    for(int8_t m = 2; m >= 0; m--) 
//    {
//      float point = (SX127X_CRYSTAL_FREQ * 1000000.0)/ ( ((4 * m) + 16) * ( (uint32_t)(1 << (e + 2)) ) );
//      
//      if(fabs(bandwidth - ((point / 1000.0) + 0.05)) <= 0.5) 
//      {
//        return((m << 3) | e);
//      }
//    }
//  }
//  return 0;
//}

uint8_t SX1278Lib::calculateBWManExp(float BW)
{
       if( (0<BW  ) && (BW<=2.6) )   return 0b00010000|0b00000111;
  else if( (2.6<BW) && (BW<=3.1) )   return 0b00001000|0b00000111;
  else if( (3.1<BW) && (BW<=3.9) )   return 0b00000000|0b00000111;

  else if( (3.9<BW) && (BW<=5.2) )   return 0b00010000|0b00000110;
  else if( (5.2<BW) && (BW<=6.3) )   return 0b00001000|0b00000110;
  else if( (6.3<BW) && (BW<=7.8) )   return 0b00000000|0b00000110;
  
  else if( (7.8<BW)  && (BW<=10.4) ) return 0b00010000|0b00000101;
  else if( (10.4<BW) && (BW<=12.5) ) return 0b00001000|0b00000101;
  else if( (12.5<BW) && (BW<=15.6) ) return 0b00000000|0b00000101;

  else if( (15.6<BW) && (BW<=20.8) ) return 0b00010000|0b00000100;
  else if( (20.8<BW) && (BW<=25.0) ) return 0b00001000|0b00000100;
  else if( (25.0<BW) && (BW<=31.3) ) return 0b00000000|0b00000100;

  else return 0b00010000|3;
}

int16_t SX1278Lib::setAFC(bool isEnabled) 
{
  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK) 
  {
    return(ERR_WRONG_MODEM);
  }

  //set AFC auto on/off
  return(SPIsetRegValue(SX127X_REG_RX_CONFIG, isEnabled ? SX127X_AFC_AUTO_ON : SX127X_AFC_AUTO_OFF, 4, 4));
}

int16_t SX1278Lib::setAFCBandwidth(float rxBw) 
{
  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK)
  {
      return(ERR_WRONG_MODEM);
  }

  CHECK_RANGE(rxBw, 2.6, 250.0, ERR_INVALID_RX_BANDWIDTH);

  // set mode to STANDBY
  int16_t state = setMode(SX127X_STANDBY);


  // set AFC bandwidth
  return(SPIsetRegValue(SX127X_REG_AFC_BW, calculateBWManExp(rxBw), 4, 0));
}

int16_t SX1278Lib::setCurrentLimit(uint8_t currentLimit) 
{
  // check allowed range
  if(!(((currentLimit >= 45) && (currentLimit <= 240)) || (currentLimit == 0))) 
  {
    return(ERR_INVALID_CURRENT_LIMIT);
  }

  // set mode to standby
  int16_t state = setMode(SX127X_STANDBY);

  // set OCP limit
  uint8_t raw;
  if(currentLimit == 0) 
  {
    // limit set to 0, disable OCP
    state |= SPIsetRegValue(SX127X_REG_OCP, SX127X_OCP_OFF, 5, 5);
  } 
  else if(currentLimit <= 120) 
  {
    raw = (currentLimit - 45) / 5;
    state |= SPIsetRegValue(SX127X_REG_OCP, SX127X_OCP_ON | raw, 5, 0);
  } 
  else if(currentLimit <= 240) 
  {
    raw = (currentLimit + 30) / 10;
    state |= SPIsetRegValue(SX127X_REG_OCP, SX127X_OCP_ON | raw, 5, 0);
  }
  return(state);
}

int16_t SX1278Lib::setRxBandwidth(float rxBw) 
{
  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK) 
  {
    return(ERR_WRONG_MODEM);
  }

  //CHECK_RANGE(rxBw, 2.6, 250.0, ERR_INVALID_RX_BANDWIDTH);

  // set mode to STANDBY
  int16_t state = setMode(SX127X_STANDBY);

  // set Rx bandwidth
  return(SPIsetRegValue(SX127X_REG_RX_BW, calculateBWManExp(rxBw), 4, 0));
}

int16_t SX1278Lib::setPreambleLength(uint16_t preambleLength) 
{
  // set mode to standby
  int16_t state = setMode(SX127X_STANDBY);


  // check active modem
  uint8_t modem = getActiveModem();
  if(modem == SX127X_LORA) 
  {
    // check allowed range
    if(preambleLength < 6) 
    {
      return(ERR_INVALID_PREAMBLE_LENGTH);
    }

    // set preamble length
    state = SPIsetRegValue(SX127X_REG_PREAMBLE_MSB, (uint8_t)((preambleLength >> 8) & 0xFF));
    state |= SPIsetRegValue(SX127X_REG_PREAMBLE_LSB, (uint8_t)(preambleLength & 0xFF));
    return(state);

  } 
  
  else if(modem == SX127X_FSK_OOK) 
  {
    // set preamble length (in bytes)
    uint16_t numBytes = preambleLength / 8;
    state = SPIsetRegValue(SX127X_REG_PREAMBLE_MSB_FSK, (uint8_t)((numBytes >> 8) & 0xFF));
    state |= SPIsetRegValue(SX127X_REG_PREAMBLE_LSB_FSK, (uint8_t)(numBytes & 0xFF));
    return(state);
  }

  return(ERR_UNKNOWN);
}

int16_t SX1278Lib::setSyncWord(uint8_t* syncWord, size_t len) 
{
  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK) {
    return(ERR_WRONG_MODEM);
  }

  CHECK_RANGE(len, 1, 8, ERR_INVALID_SYNC_WORD);

  // sync word must not contain value 0x00
  for(size_t i = 0; i < len; i++) 
  {
    if(syncWord[i] == 0x00) {
      return(ERR_INVALID_SYNC_WORD);
    }
  }

  // enable sync word recognition
  int16_t state = SPIsetRegValue(SX127X_REG_SYNC_CONFIG, SX127X_SYNC_ON, 4, 4);
  state |= SPIsetRegValue(SX127X_REG_SYNC_CONFIG, len - 1, 2, 0);


  // set sync word
  SPIwriteRegisterBurst(SX127X_REG_SYNC_VALUE_1, syncWord, len);
  return(ERR_NONE);
}

int16_t SX1278Lib::disableAddressFiltering() 
{
  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK) 
  {
    return(ERR_WRONG_MODEM);
  }

  // disable address filtering
  int16_t state = SPIsetRegValue(SX127X_REG_PACKET_CONFIG_1, SX127X_ADDRESS_FILTERING_OFF, 2, 1);


  // set node address to default (0x00)
  state = SPIsetRegValue(SX127X_REG_NODE_ADRS, 0x00);


  // set broadcast address to default (0x00)
  return(SPIsetRegValue(SX127X_REG_BROADCAST_ADRS, 0x00));
}

int16_t SX1278Lib::setRSSIConfig(uint8_t smoothingSamples, int8_t offset) 
{
  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK) {
    return(ERR_WRONG_MODEM);
  }

  // set mode to standby
  int16_t state = standby();


  // check provided values
  if(!(smoothingSamples <= 7)) {
    return(ERR_INVALID_NUM_SAMPLES);
  }

  CHECK_RANGE(offset, -16, 15, ERR_INVALID_RSSI_OFFSET);

  // set new register values
  state = SPIsetRegValue(SX127X_REG_RSSI_CONFIG, offset << 3, 7, 3);
  state |= SPIsetRegValue(SX127X_REG_RSSI_CONFIG, smoothingSamples, 2, 0);
  return(state);
}

int16_t SX1278Lib::setEncoding(uint8_t encoding) 
{
  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK) 
  {
    return(ERR_WRONG_MODEM);
  }

  // set encoding
  switch(encoding) 
  {
    case ENCODING_NRZ:
      return(SPIsetRegValue(SX127X_REG_PACKET_CONFIG_1, SX127X_DC_FREE_NONE, 6, 5));
    case ENCODING_MANCHESTER:
      return(SPIsetRegValue(SX127X_REG_PACKET_CONFIG_1, SX127X_DC_FREE_MANCHESTER, 6, 5));
    case ENCODING_WHITENING:
      return(SPIsetRegValue(SX127X_REG_PACKET_CONFIG_1, SX127X_DC_FREE_WHITENING, 6, 5));
    default:
      return(ERR_INVALID_ENCODING);
  }
}

int16_t SX1278Lib::setPacketMode(uint8_t mode, uint8_t len) 
{
  // check packet length
  if(len > SX127X_MAX_PACKET_LENGTH_FSK) 
  {
    return(ERR_PACKET_TOO_LONG);
  }

  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK) 
  {
    return(ERR_WRONG_MODEM);
  }

  // set to fixed packet length
  int16_t state = SPIsetRegValue(SX127X_REG_PACKET_CONFIG_1, mode, 7, 7);


  // set length to register
  state = SPIsetRegValue(SX127X_REG_PAYLOAD_LENGTH_FSK, len);

  // update cached value
  _packetLengthConfig = mode;
  return(state);
}

int16_t SX1278Lib::variablePacketLengthMode(uint8_t maxLen = 64) 
{
  return(setPacketMode(SX127X_PACKET_VARIABLE, maxLen));
}

int16_t SX1278Lib::configFSK() 
{
  // set RSSI threshold
  int16_t state = SPIsetRegValue(SX127X_REG_RSSI_THRESH, SX127X_RSSI_THRESHOLD);
  //ASSERT(state);

  // reset FIFO flag
  SPIwriteRegister(SX127X_REG_IRQ_FLAGS_2, SX127X_FLAG_FIFO_OVERRUN);

  // set packet configuration
  state = SPIsetRegValue(SX127X_REG_PACKET_CONFIG_1, SX127X_PACKET_VARIABLE | SX127X_DC_FREE_NONE | SX127X_CRC_ON | SX127X_CRC_AUTOCLEAR_ON | SX127X_ADDRESS_FILTERING_OFF | SX127X_CRC_WHITENING_TYPE_CCITT, 7, 0);
  state |= SPIsetRegValue(SX127X_REG_PACKET_CONFIG_2, SX127X_DATA_MODE_PACKET | SX127X_IO_HOME_OFF, 6, 5);
  //ASSERT(state);

  // set preamble polarity
  state = SPIsetRegValue(SX127X_REG_SYNC_CONFIG, SX127X_PREAMBLE_POLARITY_55, 5, 5);
  //ASSERT(state);

  // set FIFO threshold
  state = SPIsetRegValue(SX127X_REG_FIFO_THRESH, SX127X_TX_START_FIFO_NOT_EMPTY, 7, 7);
  state |= SPIsetRegValue(SX127X_REG_FIFO_THRESH, SX127X_FIFO_THRESH, 5, 0);
  //ASSERT(state);

  // disable Rx timeouts
  state = SPIsetRegValue(SX127X_REG_RX_TIMEOUT_1, SX127X_TIMEOUT_RX_RSSI_OFF);
  state |= SPIsetRegValue(SX127X_REG_RX_TIMEOUT_2, SX127X_TIMEOUT_RX_PREAMBLE_OFF);
  state |= SPIsetRegValue(SX127X_REG_RX_TIMEOUT_3, SX127X_TIMEOUT_SIGNAL_SYNC_OFF);
  //ASSERT(state);

  // enable preamble detector
  state = SPIsetRegValue(SX127X_REG_PREAMBLE_DETECT, SX127X_PREAMBLE_DETECTOR_ON | SX127X_PREAMBLE_DETECTOR_2_BYTE | SX127X_PREAMBLE_DETECTOR_TOL);

  return(state);
}

int16_t SX1278Lib::setFrequencyRaw(float newFreq) 
{
  int16_t state = ERR_NONE;

  // set mode to standby if not FHSS
  if(SPIgetRegValue(SX127X_REG_HOP_PERIOD) == SX127X_HOP_PERIOD_OFF) 
  {
    state = setMode(SX127X_STANDBY);
  }

  // calculate register values
  uint32_t FRF = (newFreq * (uint32_t(1) << SX127X_DIV_EXPONENT)) / SX127X_CRYSTAL_FREQ;

  // write registers
  state |= SPIsetRegValue(SX127X_REG_FRF_MSB, (FRF & 0xFF0000) >> 16);
  state |= SPIsetRegValue(SX127X_REG_FRF_MID, (FRF & 0x00FF00) >> 8);
  state |= SPIsetRegValue(SX127X_REG_FRF_LSB, FRF & 0x0000FF);
  return(state);
}

int16_t SX1278Lib::setFrequency(float freq) 
{
  CHECK_RANGE(freq, 137.0, 525.0, ERR_INVALID_FREQUENCY);

  // set frequency and if successful, save the new setting
  int16_t state = setFrequencyRaw(freq);
  if(state == ERR_NONE) 
  {
    _freq = freq;
  }
  return(state);
}

int16_t SX1278Lib::setDataShaping(uint8_t sh) 
{
  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK) 
  {
    return(ERR_WRONG_MODEM);
  }

  // check modulation
  if(_ook) 
  {
    // we're in OOK mode, the only thing we can do is disable
    if(sh == SHAPING_NONE) {
      return(setDataShapingOOK(0));
    }

    return(ERR_INVALID_MODULATION);
  }

  // set mode to standby
  int16_t state = standby();
  //ASSERT(state);

  // set data shaping
  switch(sh) {
    case SHAPING_NONE:
      return(SPIsetRegValue(SX127X_REG_PA_RAMP, SX1278_NO_SHAPING, 6, 5));
    case SHAPING_0_3:
      return(SPIsetRegValue(SX127X_REG_PA_RAMP, SX1278_FSK_GAUSSIAN_0_3, 6, 5));
    case SHAPING_0_5:
      return(SPIsetRegValue(SX127X_REG_PA_RAMP, SX1278_FSK_GAUSSIAN_0_5, 6, 5));
    case SHAPING_1_0:
      return(SPIsetRegValue(SX127X_REG_PA_RAMP, SX1278_FSK_GAUSSIAN_1_0, 6, 5));
    default:
      return(ERR_INVALID_DATA_SHAPING);
  }
}

int16_t SX1278Lib::setDataShapingOOK(uint8_t sh) 
{
  // check active modem
  if(getActiveModem() != SX127X_FSK_OOK)
  {
    return(ERR_WRONG_MODEM);
  }

  // check modulation
  if(!_ook) {
    return(ERR_INVALID_MODULATION);
  }

  // set mode to standby
  int16_t state = standby();

  // set data shaping
  switch(sh) 
  {
    case 0:
      state |= SPIsetRegValue(SX127X_REG_PA_RAMP, SX1278_NO_SHAPING, 6, 5);
      break;
    case 1:
      state |= SPIsetRegValue(SX127X_REG_PA_RAMP, SX1278_OOK_FILTER_BR, 6, 5);
      break;
    case 2:
      state |= SPIsetRegValue(SX127X_REG_PA_RAMP, SX1278_OOK_FILTER_2BR, 6, 5);
      break;
    default:
      return(ERR_INVALID_DATA_SHAPING);
  }

  return(state);
}

int16_t SX1278Lib::setOutputPower(int8_t power, bool useRfo) 
{
  // check allowed power range
  if(useRfo) 
  {
    // RFO output
    CHECK_RANGE(power, -3, 15, ERR_INVALID_OUTPUT_POWER);
  } 
  else 
  {
    // PA_BOOST output, check high-power operation
    if(power != 20) 
    {
      CHECK_RANGE(power, 2, 17, ERR_INVALID_OUTPUT_POWER);
    }
  }

  // set mode to standby
  int16_t state = standby();

  if(useRfo) 
  {
    uint8_t paCfg = 0;
    if(power < 0) 
    {
      // low power mode RFO output
      paCfg = SX1278_LOW_POWER | (power + 3);
    } 
    else 
    {
      // high power mode RFO output
      paCfg = SX1278_MAX_POWER | power;
    }

    state |= SPIsetRegValue(SX127X_REG_PA_CONFIG, SX127X_PA_SELECT_RFO, 7, 7);
    state |= SPIsetRegValue(SX127X_REG_PA_CONFIG, paCfg, 6, 0);
    state |= SPIsetRegValue(SX1278_REG_PA_DAC, SX127X_PA_BOOST_OFF, 2, 0);

  } 
  else 
  {
    if(power != 20) 
    {
      // power is 2 - 17 dBm, enable PA1 + PA2 on PA_BOOST
      state |= SPIsetRegValue(SX127X_REG_PA_CONFIG, SX127X_PA_SELECT_BOOST, 7, 7);
      state |= SPIsetRegValue(SX127X_REG_PA_CONFIG, SX1278_MAX_POWER | (power - 2), 6, 0);
      state |= SPIsetRegValue(SX1278_REG_PA_DAC, SX127X_PA_BOOST_OFF, 2, 0);

    } 
    else 
    {
      // power is 20 dBm, enable PA1 + PA2 on PA_BOOST and enable high power control
      state |= SPIsetRegValue(SX127X_REG_PA_CONFIG, SX127X_PA_SELECT_BOOST, 7, 7);
      state |= SPIsetRegValue(SX127X_REG_PA_CONFIG, SX1278_MAX_POWER | 0x0F, 6, 0);
      state |= SPIsetRegValue(SX1278_REG_PA_DAC, SX127X_PA_BOOST_ON, 2, 0);

    }
  }

  return(state);
}

int16_t SX1278Lib::directMode() 
{
  // set mode to standby
  int16_t state = setMode(SX127X_STANDBY);
  //ASSERT(state);

  // set DIO mapping
  state = SPIsetRegValue(SX127X_REG_DIO_MAPPING_1, SX127X_DIO1_CONT_DCLK | SX127X_DIO2_CONT_DATA, 5, 2);
  //ASSERT(state);

  // enable receiver startup without preamble or RSSI
  state = setAFCAGCTrigger(SX127X_RX_TRIGGER_NONE);
  //ASSERT(state);

  // set continuous mode
  return(SPIsetRegValue(SX127X_REG_PACKET_CONFIG_2, SX127X_DATA_MODE_CONTINUOUS, 6, 6));
}

int16_t SX1278Lib::transmitDirect(uint32_t frf ) 
{
  // check modem
  if(getActiveModem() != SX127X_FSK_OOK) 
  {
    return(ERR_WRONG_MODEM);
  }


  // user requested to start transmitting immediately (required for RTTY)
  if(frf != 0) 
  {
    SPIwriteRegister(SX127X_REG_FRF_MSB, (frf & 0xFF0000) >> 16);
    SPIwriteRegister(SX127X_REG_FRF_MID, (frf & 0x00FF00) >> 8);
    SPIwriteRegister(SX127X_REG_FRF_LSB, frf & 0x0000FF);

    return(setMode(SX127X_TX));
  }

  // activate direct mode
  int16_t state = directMode();
  //ASSERT(state);

  // apply fixes to errata
  //ERRATA_SX127X(false);

  // start transmitting
  return(setMode(SX127X_TX));
}

int16_t SX1278Lib::receiveDirect() 
{
  // check modem
  if(getActiveModem() != SX127X_FSK_OOK) {
    return(ERR_WRONG_MODEM);
  }

  // activate direct mode
  int16_t state = directMode();

  // start receiving
  return(setMode(SX127X_RX));
}

int16_t SX1278Lib::beginFSK(float freq, float br, float freqDev, float rxBw, int power, uint16_t preambleLength, bool enableOOK) 
{

  // set mode to standby
  int16_t state = standby();
  Serial.println(state);
  // check currently active modem
  if(getActiveModem() != SX127X_FSK_OOK) 
  {
    // set FSK mode
    state = setActiveModem(SX127X_FSK_OOK);
  }

  // enable/disable OOK
  state = setOOK(enableOOK);
  Serial.println(state);
  
  // set bit rate
  state = setBitRate(br);
  Serial.println(state);
  
  // set frequency deviation
  state = setFrequencyDeviation(freqDev);
  Serial.println(state);

  // set AFC bandwidth
  state = setAFCBandwidth(rxBw);
  Serial.println(state);
  
  // set AFC&AGC trigger to RSSI (both in OOK and FSK)
  state = setAFCAGCTrigger(SX127X_RX_TRIGGER_RSSI_INTERRUPT);
  Serial.println(state);
  
  // enable AFC
  state = setAFC(false);
  Serial.println(state);
  
  // set receiver bandwidth
  state = setRxBandwidth(rxBw);
  Serial.println(state);

  // set over current protection
  state = setCurrentLimit(60);
  Serial.println(state);

  // set preamble length
  state = setPreambleLength(preambleLength);
  Serial.println(state);

  // set default sync word
  uint8_t syncWord[] = {0x12, 0xAD};
  state = setSyncWord(syncWord, 2);
  Serial.println(state);

  // disable address filtering
  state = disableAddressFiltering();
  Serial.println(state);

  // set default RSSI measurement config
  state = setRSSIConfig(2,0);
  Serial.println(state);

  // set default encoding
  state = setEncoding(ENCODING_NRZ);
  Serial.println(state);

  // set default packet length mode
  state = variablePacketLengthMode();
  Serial.println(state);
  
  // configure settings not accessible by API
  state = configFSK();
  setFrequency(freq);
  Serial.println(state);
  
  setDataShaping(SX1278_NO_SHAPING);

  state = setOutputPower(power);
  Serial.println(state);
  
  return(state);
}
