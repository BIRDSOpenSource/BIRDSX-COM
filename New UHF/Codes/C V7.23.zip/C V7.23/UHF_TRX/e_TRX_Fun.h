void RX_MODE()
{  
  digitalWrite(RFSW_V1   ,HIGH  ); digitalWrite(RFSW_V2   ,HIGH ); // SX1278 RX mode

  digitalWrite(SW_5V     ,LOW  );
  digitalWrite(BOOST_5V  ,LOW  );
  delay(50);
  digitalWrite(SW_3V     ,LOW  );            
}

void GFSK_TX_MODE()
{ 
  digitalWrite(RFSW_V1   ,HIGH  ); digitalWrite(RFSW_V2   ,LOW ); // SX1278 GMSK mode

  digitalWrite(SW_3V     ,LOW  );  
  delay(100);
  digitalWrite(BOOST_5V  ,HIGH  );
  delay(100);
  //digitalWrite(SW_5V     ,HIGH  );   
}

void CW_TX_MODE()
{
  digitalWrite(RFSW_V1   ,HIGH  ); digitalWrite(RFSW_V2   ,LOW ); // SX1278 CW mode
  
  digitalWrite(SW_5V     ,LOW  );
  digitalWrite(BOOST_5V  ,LOW  ); 
  delay(100);
  digitalWrite(SW_3V     ,HIGH );  
}


void NEW_CW_TX_MODE(float frequency, float br, float fd,  int8_t p  )
{
  CW_TX_MODE();
  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  radio.setFrequency(frequency);
  radio.setBitRate(br);  //1.2
  radio.setFrequencyDeviation(fd); //0.6
  radio.setOutputPower(p, true);    // 10
  radio.setCurrentLimit(150);
    
  radio.transmitDirect();
}

//_____________________________________________________________________________________________________________________________________________
void GFSK_DIRECT_MODE_TX(float frequency, float br, float fd, float rxbw, int8_t p  )
{
  GFSK_TX_MODE();
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  radio.setOOK(false);
  radio.setFrequency(frequency);
  radio.setBitRate(br);  //4.8         
  radio.setFrequencyDeviation(fd); // 1.2
  //radio.setRxBandwidth(rxbw);     //25
  radio.setOutputPower(p, true);        // 0
  radio.setCurrentLimit(100);
  radio.setDataShaping(SHAPING_0_5);
}

//_____________________________________________________________________________________________________________________________________________
void GFSK_DIRECT_MODE_RX(float frequency, float br, float fd, float rxbw)
{
  RX_MODE();
  //++++++++++++++++++++++++++++++++++++++++++++++++
   
  radio.setOOK(false);
  radio.setFrequency(frequency);
  radio.setBitRate(br);  //4.8         
  radio.setFrequencyDeviation(fd); // 1.2
  radio.setRxBandwidth(rxbw);     //25 +0.95
  radio.setDataShaping(SHAPING_0_5);
  if( AFC == 1 )
  {
    radio.setAFCBandwidth(AFC_BW);
    radio.setAFC(true);
    radio.setAFCAGCTrigger(SX127X_AFC_AUTO_ON|SX127X_RX_TRIGGER_RSSI_INTERRUPT);
  }
  radio.receiveDirect(); 
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void CHECK_COMPIC_COMMANDS()
{   
  if( Serial2.available() )
  {
    if( Serial2.read() == 0x7E )
    {
      COMP_CW_DATA_ARRAY[0] = 0x7E ;
      delay(10);
      for( int i = 1; i<=60; i++ )
      {
        COMP_CW_DATA_ARRAY[i] = Serial2.read();
      }
    }
    
    if( (COMP_CW_DATA_ARRAY[0] == 0x7E) && (COMP_CW_DATA_ARRAY[50] == 0x7E) )
    {  
      Serial.print("Received Command form COMPIC = ");
      for( int i = 0; i<51; i++)
      {
        Serial.print( COMP_CW_DATA_ARRAY[i], HEX );
        Serial.print(" ");
      }
      Serial.println();

      // ack to comapic
      Serial2.write(0x7E);
      Serial2.write(COMP_CW_DATA_ARRAY[1]);
      Serial2.write(0x7E);
  
      if( COMP_CW_DATA_ARRAY[1] == 0xAA )
      {
        //CW_TX_MODE();
        radio.setOOK(true);
        NEW_CW_TX_MODE(TX_FREQUENCY, 0.6, 0.15, CW_POWER); //(float frequency, float br, float fd,  int8_t p  )
        Serial.println("CW Mode"); 
  
        
        //radio.transmitDirect();
        uint8_t CW_LENGTH = COMP_CW_DATA_ARRAY[2];
        
        if( CW_LENGTH <= 50)
        {
          for(int i=3; i<CW_LENGTH+3; i++)
          {
            IWatchdog.reload();;
            CW_LETTER( COMP_CW_DATA_ARRAY[i] );
            Serial.print( COMP_CW_DATA_ARRAY[i], HEX); Serial.print(" ");
          }
          Serial.println("");
        }
        else Serial.println("Wrong CW format");
        
  
        Serial.println("CW transmission finished");
    
        //RX_MODE();
        GFSK_DIRECT_MODE_RX( RX_FREQUENCY, Data_Rate, RX_FD, RX_Bandwidth);  //435.3064 ___ 435.3079          newboard   
        Serial.println("RX mode on");
      }

      else if ( COMP_CW_DATA_ARRAY[1] == 0xD1 )
      {
        Serial.println("Tranceiver settings commad from ComPic");
        WRITE_TRANCEIVER_SETTINGS_IN_EEPROM_BY_COMPIC() ;
      }

      else if ( COMP_CW_DATA_ARRAY[1] == 0xD2 )
      {
        Serial.println("Tranceiver RX freq update CMD from ComPic");
        WRITE_RX_FREQUENCY_IN_EEPROM_BY_COMPIC();
      }

      else if ( COMP_CW_DATA_ARRAY[1] == 0xD3 )
      {
        Serial.println("Tranceiver TX freq update CMD from ComPic");
        WRITE_TX_FREQUENCY_IN_EEPROM_BY_COMPIC();

      }
      
      else Serial.println("Not corect command format from compic");
  
      MLC = 0;
      for(int i=0; i<51; i++) COMP_CW_DATA_ARRAY[i] = 0;
      COMP_CWB_Counter = 0;
      flushSerial2();
    }
  }
}

uint8_t RI = 0;
uint8_t p  = 0;
uint16_t crc;

uint8_t C1,C2,C3;

void RECEIVE_GS_CMD()
{    
  IWatchdog.reload();
  
  // DATA is sampled on the rising edge of DCLK and updated 
  // on the falling edge..
  INITIALIZE_RX_PARAMETERS();
  do
  {
    while(digitalRead(Dclock_PIN) == 0); // Waiting for the rising edge.                          
    reception = Process_RX_Bit(RAWData, digitalRead(Data_IN_PIN));
    
    while(digitalRead(Dclock_PIN) == 1); // Waiting for the falling edge.   
    if( digitalRead(PA0) == HIGH ) break;
    
    CHECK_COMPIC_COMMANDS();
  }
  while( reception );                        // If AX25_analyzeNextBit returns 0 -> we have a frame

  if( (RAWData[1] == 0x54) && (digitalRead(PA0) == LOW) )
  {
    Byte_Counter++;     // Length of the frame is Byte_Counter + 1.
    crc = AX25_computeCRC(RAWData, Byte_Counter);   
    
    if(RAWData[Byte_Counter - 3] == (crc & 0xff))
    {      
      if(RAWData[Byte_Counter - 2] == ((crc >> 8) & 0xff)) 
      {         
        for(int i = 0; i<= Byte_Counter; i++)
        {
          RX_Buffer[i] = RAWData[i];
        }     
        RX_Buffer[Byte_Counter] = 0x7E ;

        for( int p = 1; p<= Byte_Counter; p++)
        {
          Serial2.write(RX_Buffer[p]);
          Serial.print( RX_Buffer[p], HEX);
          Serial.print(" ");
        }
        Serial.println();
      }  
    }
  }
}


void TRANSMIT_PACKETS()
{
  while( Serial2.available() )
  {
    COMP_DATA_ARRAY[COMPB_Counter] = Serial2.read();
    COMPB_Counter++;
  }

  if( COMPB_Counter > 100 )
  {
    for(int i = 0; i<5; i++)
    {
      if( COMP_DATA_ARRAY[i] == 0x7E )
      {
        POSC = i;
        break;
      }
    }
  }

  if( (COMP_DATA_ARRAY[POSC] == 0x7E) && (COMP_DATA_ARRAY[POSC+106] == 0x7E) )
  {
    IWatchdog.reload();
    digitalWrite(FEED_BACK_PIN,HIGH);
    if( pcktc == 0 )
    {
      radio.transmitDirect();
      TX_DELAY = 100 ;                  // 500ms delay
      digitalWrite(SW_5V     ,HIGH  );  
    }
    else
    {
      TX_DELAY = 60;
    }

    pcktc++;
    Serial.print(pcktc,DEC);
    Serial.println("-->");
    //COMP_DATA_ARRAY[22] = 0x2F;
    //AX25_putCRC(COMP_DATA_ARRAY,107);
    for(int i=0; i<107; i++)           //1 to 103
    {
        TX_DATA_ARRAY[i] = COMP_DATA_ARRAY[POSC+i];
        //Serial.print(TX_DATA_ARRAY[i], HEX);
        //Serial.print(" ");
    }   
    // Serial.print(TX_DATA_ARRAY[104], HEX);
    // Serial.print(" ");
    // Serial.print(TX_DATA_ARRAY[105], HEX);
    // Serial.println();
    TXAC = 107;

    // In Tx mode, a synchronous data clock for an external uC is 
    // provided on DIO1/DCLK pin. DATA is internally sampled 
    // on the rising edge of DCLK so the uC can change logic state
    // anytime outside the grayed out setup/hold zone.
    
    AX25_txInitCfg(); 
    
    do
    {
      while(digitalRead(Dclock_PIN) == 1);  // Waiting for a fallling edge.
      if(TXbit_to_FModulation) digitalWrite(Data_OUT_PIN, HIGH);
      else                     digitalWrite(Data_OUT_PIN, LOW );
      transmission = Prepare_NextBit_To_Send(TX_DATA_ARRAY);
      while(digitalRead(Dclock_PIN) == 0);  // Waiting for the rising edge
    }while(transmission);  


    for(int i=0; i<=106; i++)           //1 to 103
    {
        COMP_DATA_ARRAY[i+POSC] = 0;
    }
    
    COMPB_Counter = 0;
    flushSerial2();
    digitalWrite(FEED_BACK_PIN,LOW);
  }
}
