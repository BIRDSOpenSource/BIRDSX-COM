void GFSK_DIRECT_MODE_RX(float frequency, float br, float fd, float rxbw);

/*___________________________________________________________________________*
 * Declaration of the global variables for Tx.
 *___________________________________________________________________________*/

//**************************************
uint32_t counter = 0;
uint32_t MLC = 0;


uint8_t pcktc = 0;

#define TRX_STNDBY             0x00
#define CWMC_TX                0x01
#define GFSK_TX                0x02
#define GFSK_RX                0x03


uint8_t COMP_DATA_ARRAY[120];
uint8_t COMPB_Counter = 0;
uint8_t POSC = 0;

uint8_t TX_DATA_ARRAY[225];
uint8_t TXAC =0;

uint8_t COMP_CW_DATA_ARRAY[70];
uint8_t COMP_CWB_Counter = 0;

uint8_t received = 0;

///////////////////RX Related things////////////////////////////////
//____________RX Data Buffer_____________________________________________________
uint8_t RAWData[120]  ;
uint8_t RX_Buffer[120];

int rxMode;
int rxBit;
int reception;

void flushSerial2()
{
  while( Serial2.available() ) 
  {
    Serial2.read();
  }
}

void flushSerial1()
{
  while( Serial.available() ) 
  {
    Serial.read();
  }
}


// EEPROM handling function from here
unsigned short CRC_CALC(uint8_t buffer[], uint16_t size_frame) 
{
  unsigned int i, j;
  unsigned short shiftRegister, outBit;
  char _byte;

  // Initialization of the Shift Register to 0xFFFF
  shiftRegister = 0xFFFF;

  for(i=0 ; i<size_frame; i++)   
  {
    _byte = buffer[i];

    for(j=0; j<8; j++) 
    {
      outBit = shiftRegister & 0x0001;
      shiftRegister >>= 0x01;  // Shift the register to the right.

      if(outBit != (_byte & 0x01)) 
      {
        shiftRegister ^= 0x8408;  // Mirrored polynom.
        _byte >>= 0x01;
        continue;
      }
      _byte >>= 0x01;
    }
  }
  return shiftRegister^ 0xFFFF;  // Final XOR.
}


// this part handles the RX fequency control section______________________
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//________________________________________________________________________
uint8_t SERIAL_BUFFER[50];
uint8_t EEPROM_WRITE_BUFFER[50];
uint8_t EEPROM_READ_BUFFER[50];

void WRITE_RX_FREQUENCY_IN_EEPROM()
{
  if( SERIAL_BUFFER[1] == 0x52 )
  {
    // #T456.3768#
    uint16_t ROUND_PART = (SERIAL_BUFFER[2]-0x30)*100  + (SERIAL_BUFFER[3]-0x30)*10  + (SERIAL_BUFFER[4]-0x30);
    uint16_t DEC_PART   = (SERIAL_BUFFER[6]-0x30)*1000 + (SERIAL_BUFFER[7]-0x30)*100 + (SERIAL_BUFFER[8]-0x30)*10 + (SERIAL_BUFFER[9]-0x30);               
                     
    Serial.print(ROUND_PART,HEX); Serial.println(DEC_PART,HEX);

    RX_FREQUENCY = (float)ROUND_PART + ((float)DEC_PART) / 10000;
    GFSK_DIRECT_MODE_RX( RX_FREQUENCY, Data_Rate, RX_FD, RX_Bandwidth );  //435.3064 ___ 435.3079          newboard   
    Serial.print("RX frequency changed to - ");
    Serial.println(RX_FREQUENCY, 4);
    
    EEPROM_WRITE_BUFFER[0] = (uint8_t)((ROUND_PART>>8)&0x00FF) ;  
    EEPROM_WRITE_BUFFER[1] = (uint8_t)( ROUND_PART    &0x00FF) ;  
    EEPROM_WRITE_BUFFER[2] = (uint8_t)((DEC_PART  >>8)&0x00FF) ;
    EEPROM_WRITE_BUFFER[3] = (uint8_t)( DEC_PART      &0x00FF) ;
    
    uint16_t CRC_VAL = CRC_CALC(EEPROM_WRITE_BUFFER,4);
    EEPROM_WRITE_BUFFER[4] = (uint8_t)((CRC_VAL>>8)&0x00FF);
    EEPROM_WRITE_BUFFER[5] = (uint8_t)( CRC_VAL &0x00FF )  ;
    
    for(int q = 0; q<5; q++)                      
    {
      for( int i =0; i<6; i++)
      {
        EEPROM.update( i+10*q, EEPROM_WRITE_BUFFER[i] );
      } 

      Serial.print("Reading RX frequency related section = ");
      Serial.print(q, DEC);
      Serial.print(" | ");
      for( int i = 0; i<6; i++)
      {
        Serial.print( EEPROM.read(i+10*q), HEX );
        Serial.print(" ");
      }
      Serial.println();  
    }
  }
}

// this part handles the RX fequency control section______________________
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void LOAD_EEPROM_RX_FREQUENCY()
{ 
  int CRC_MATCHED_FLAG = 0x00;
  
  for(int q = 0; q<5; q++)                      
  {
    for( int i =0; i<6; i++)
    {
      EEPROM_READ_BUFFER[i] = EEPROM.read( i+10*q );
    } 

    Serial.print("Reading Receiving frequency Section number = ");
    Serial.print(q, DEC);
    Serial.print(" | ");
    for( int i = 0; i<6; i++)
    {
      Serial.print( EEPROM_READ_BUFFER[i], HEX );
      Serial.print(" ");
    }
    Serial.println();  

    uint16_t CRCVAL = CRC_CALC(EEPROM_READ_BUFFER, 4);
    uint8_t C1 = (uint8_t)((CRCVAL>>8)&0x00FF);
    uint8_t C2 = (uint8_t)( CRCVAL &0x00FF   );
    
    if( (EEPROM_READ_BUFFER[4] == C1) && (EEPROM_READ_BUFFER[5] == C2)  )
    {
      uint16_t RP = ((uint16_t)EEPROM_READ_BUFFER[0] <<8) + (uint16_t)EEPROM_READ_BUFFER[1];
      uint16_t DP = ((uint16_t)EEPROM_READ_BUFFER[2] <<8) + (uint16_t)EEPROM_READ_BUFFER[3];

      RX_FREQUENCY = (float)RP + ((float)DP) / 10000;
      Serial.print("RX Frequency = ");
      Serial.print(RX_FREQUENCY, 4);
      Serial.println(" MHz");
      
      CRC_MATCHED_FLAG = 0x96;
      break;
    }

    else Serial.println("CRC not matched trying again");


  }

  if( CRC_MATCHED_FLAG == 0x00)
  {
    Serial.println("CRC not matched default RX frequency set");
    
    //RX_FREQUENCY = 435.308;
    Serial.print("RX Frequency = ");
    Serial.print(RX_FREQUENCY, 4);
    Serial.println(" MHz");
  }
  Serial.println();
}


//_________________________________________________________________________
void WRITE_TX_FREQUENCY_IN_EEPROM()
{
  if( SERIAL_BUFFER[1] == 0x54 )
  {
    // #T456.3768#
    uint16_t ROUND_PART = (SERIAL_BUFFER[2]-0x30)*100 + (SERIAL_BUFFER[3]-0x30)*10 + (SERIAL_BUFFER[4]-0x30);
    uint16_t DEC_PART   = (SERIAL_BUFFER[6]-0x30)*1000 + (SERIAL_BUFFER[7]-0x30)*100 + (SERIAL_BUFFER[8]-0x30)*10 + (SERIAL_BUFFER[9]-0x30);               
                     
    Serial.print(ROUND_PART,HEX); Serial.println(DEC_PART,HEX);

    TX_FREQUENCY = float(ROUND_PART) + (float(DEC_PART)) / 10000;
    //radio.setFrequency(TX_FREQUENCY); no need
    Serial.print("TX frequency changed to - ");
    Serial.println(TX_FREQUENCY, 4);
    
    EEPROM_WRITE_BUFFER[0] = (uint8_t)((ROUND_PART>>8)&0x00FF) ;  
    EEPROM_WRITE_BUFFER[1] = (uint8_t)( ROUND_PART    &0x00FF) ;  
    EEPROM_WRITE_BUFFER[2] = (uint8_t)((DEC_PART  >>8)&0x00FF) ;
    EEPROM_WRITE_BUFFER[3] = (uint8_t)( DEC_PART      &0x00FF) ;
    
    uint16_t CRC_VAL = CRC_CALC(EEPROM_WRITE_BUFFER,4);
    EEPROM_WRITE_BUFFER[4] = (uint8_t)((CRC_VAL>>8)&0x00FF);
    EEPROM_WRITE_BUFFER[5] = (uint8_t)( CRC_VAL &0x00FF )  ;
    
    for(int q = 0; q<5; q++)                      
    {
      for( int i =0; i<6; i++)
      {
        EEPROM.update( i+10*q+50, EEPROM_WRITE_BUFFER[i] );
      } 

      Serial.print("Reading TX frequency related section = ");
      Serial.print(q, DEC);
      Serial.print(" | ");
      for( int i = 0; i<6; i++)
      {
        Serial.print( EEPROM.read(i+10*q+50), HEX );
        Serial.print(" ");
      }
      Serial.println();  
    }
  }
}

//________________________________________________________________________
void LOAD_EEPROM_TX_FREQUENCY()
{ 
  int CRC_MATCHED_FLAG = 0x00;
  
  for(int q = 0; q<5; q++)                      
  {
    for( int i =0; i<6; i++)
    {
      EEPROM_READ_BUFFER[i] = EEPROM.read( i+10*q+50 );
    } 

    Serial.print("Reading Transmission frequency Section number = ");
    Serial.print(q, DEC);
    Serial.print(" | ");
    for( int i = 0; i<6; i++)
    {
      Serial.print( EEPROM_READ_BUFFER[i], HEX );
      Serial.print(" ");
    }
    Serial.println();  

    uint16_t CRCVAL = CRC_CALC(EEPROM_READ_BUFFER, 4);
    uint8_t C1 = (uint8_t)((CRCVAL>>8)&0x00FF)  ;
    uint8_t C2 = (uint8_t)( CRCVAL    &0x00FF)  ;
    
    if( (EEPROM_READ_BUFFER[4] == C1) && (EEPROM_READ_BUFFER[5] == C2)  )
    {
      uint16_t RP = ((uint16_t)EEPROM_READ_BUFFER[0] <<8) + (uint16_t)EEPROM_READ_BUFFER[1];
      uint16_t DP = ((uint16_t)EEPROM_READ_BUFFER[2] <<8) + (uint16_t)EEPROM_READ_BUFFER[3];

      TX_FREQUENCY = (float)RP + ((float)DP) / 10000;
      Serial.print("TX Frequency = ");
      Serial.print(TX_FREQUENCY, 4);
      Serial.println(" MHz");
      
      CRC_MATCHED_FLAG = 0x96;
      break;
    }

    else Serial.println("CRC not matched trying again");


  }

  if( CRC_MATCHED_FLAG == 0x00)
  {
    Serial.println("CRC not matched default TX frequency set");
    
    //RX_FREQUENCY = 435.308;
    Serial.print("TX Frequency = ");
    Serial.print(TX_FREQUENCY, 4);
    Serial.println(" MHz");
  }
  Serial.println();
}

void WRITE_TRANCEIVER_SETTINGS_IN_EEPROM()
{
  if( SERIAL_BUFFER[1] == 0x53 )   //S
  {
    // Extracting GMSK TX power______
    EEPROM_WRITE_BUFFER[0] = 10*(SERIAL_BUFFER[2]-0x30) + (SERIAL_BUFFER[3]-0x30) ;
    // Extracting GMSK CW power______
    EEPROM_WRITE_BUFFER[1] = 10*(SERIAL_BUFFER[4]-0x30) + (SERIAL_BUFFER[5]-0x30) ;             

    // Extracting GMSK TX Frequency deviation_____
    EEPROM_WRITE_BUFFER[2] = 10*(SERIAL_BUFFER[6]-0x30) + (SERIAL_BUFFER[8]-0x30) ;
    // Extracting GMSK RX Frequency deviation
    EEPROM_WRITE_BUFFER[3] = 10*(SERIAL_BUFFER[9]-0x30) + (SERIAL_BUFFER[11]-0x30) ;

    // Extracting RX Bandwidth_____
    EEPROM_WRITE_BUFFER[4] = 100*(SERIAL_BUFFER[12]-0x30)+ 10*(SERIAL_BUFFER[13]-0x30) + (SERIAL_BUFFER[15]-0x30) ;

    // Extracting Data rate Bandwidth_____
    EEPROM_WRITE_BUFFER[5] = 100*(SERIAL_BUFFER[16]-0x30)+ 10*(SERIAL_BUFFER[17]-0x30) + (SERIAL_BUFFER[19]-0x30) ;

    // Extracting the AFC status
    EEPROM_WRITE_BUFFER[6] = 100*(SERIAL_BUFFER[20]-0x30)+ 10*(SERIAL_BUFFER[21]-0x30) + (SERIAL_BUFFER[23]-0x30) ;
    
    uint16_t CRC_VAL = CRC_CALC(EEPROM_WRITE_BUFFER,7);
    EEPROM_WRITE_BUFFER[7] = (uint8_t)((CRC_VAL>>8)&0x00FF);
    EEPROM_WRITE_BUFFER[8] = (uint8_t)( CRC_VAL &0x00FF )  ;

    FSK_POWER    = (int) EEPROM_WRITE_BUFFER[0];
    CW_POWER     = (int) EEPROM_WRITE_BUFFER[1];
    TX_FD        = ((float)(EEPROM_WRITE_BUFFER[2])) /10; 
    RX_FD        = ((float)(EEPROM_WRITE_BUFFER[3])) /10; 
    RX_Bandwidth = ((float) EEPROM_WRITE_BUFFER[4])/10;
    Data_Rate    = ((float)(EEPROM_WRITE_BUFFER[5])) /10;
    if( EEPROM_WRITE_BUFFER[6] != 0 )
    {
      AFC = 1;
      AFC_BW = ((float)EEPROM_WRITE_BUFFER[6])/10;
    }
    else AFC = 0;
    
    Serial.print("FSK_POWER = "); Serial.println(FSK_POWER, DEC);
    Serial.print("CW_POWER = "); Serial.println(CW_POWER, DEC);
    Serial.print("TX_FD = "); Serial.println(TX_FD, 2);
    Serial.print("RX_FD = "); Serial.println(RX_FD, 2);
    Serial.print("RX_Bandwidth = "); Serial.println(RX_Bandwidth, DEC);
    Serial.print("Data_Rate = "); Serial.println(Data_Rate, 2);
    if( AFC != 0 )
    {
      Serial.println("AFC = ON");
      Serial.print("AFC_BW = "); Serial.println(AFC_BW, 2);
    }
    else Serial.println("AFC = OFF");
    
    

    radio.setBitRate(Data_Rate);  //4.8         
    radio.setFrequencyDeviation(RX_FD); // 1.2
    radio.setRxBandwidth(RX_Bandwidth);     //25
    radio.receiveDirect();
    
    for(int q = 0; q<5; q++)                      
    {
      for( int i =0; i<9; i++)
      {
        EEPROM.update( i+10*q+100, EEPROM_WRITE_BUFFER[i] );
      } 

      Serial.print("Reading TX frequency related section = ");
      Serial.print(q, DEC);
      Serial.print(" | ");
      for( int i = 0; i<9; i++)
      {
        Serial.print( EEPROM.read(i+10*q+100), HEX );
        Serial.print(" ");
      }
      Serial.println();  
    }
  }
}

// compic cmd//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void WRITE_TRANCEIVER_SETTINGS_IN_EEPROM_BY_COMPIC()
{
  // Extracting GMSK TX power______
  EEPROM_WRITE_BUFFER[0] = COMP_CW_DATA_ARRAY[2] ;
  // Extracting GMSK CW power______
  EEPROM_WRITE_BUFFER[1] = COMP_CW_DATA_ARRAY[3] ;             

  // Extracting GMSK TX Frequency deviation_____
  EEPROM_WRITE_BUFFER[2] = COMP_CW_DATA_ARRAY[4] ;
  // Extracting GMSK RX Frequency deviation
  EEPROM_WRITE_BUFFER[3] = COMP_CW_DATA_ARRAY[5] ;

  // Extracting RX Bandwidth_____
  EEPROM_WRITE_BUFFER[4] = COMP_CW_DATA_ARRAY[6] ;

  // Extracting Data rate Bandwidth_____
  EEPROM_WRITE_BUFFER[5] = COMP_CW_DATA_ARRAY[7] ;

  // Extracting the AFC status
  EEPROM_WRITE_BUFFER[6] = COMP_CW_DATA_ARRAY[8] ;
  
  uint16_t CRC_VAL = CRC_CALC(EEPROM_WRITE_BUFFER,7);
  EEPROM_WRITE_BUFFER[7] = (uint8_t)((CRC_VAL>>8)&0x00FF);
  EEPROM_WRITE_BUFFER[8] = (uint8_t)( CRC_VAL    &0x00FF);

  FSK_POWER    = (int) EEPROM_WRITE_BUFFER[0];
  CW_POWER     = (int) EEPROM_WRITE_BUFFER[1];
  TX_FD        = ((float)(EEPROM_WRITE_BUFFER[2])) /10; 
  RX_FD        = ((float)(EEPROM_WRITE_BUFFER[3])) /10; 
  RX_Bandwidth =  (float) EEPROM_WRITE_BUFFER[4]   /10;
  Data_Rate    = ((float)(EEPROM_WRITE_BUFFER[5])) /10; 
  if( EEPROM_WRITE_BUFFER[6] != 0 )
  {
    AFC = 1;
    AFC_BW = ((float)EEPROM_WRITE_BUFFER[6])/10;
  }
  else AFC = 0;
  
  Serial.print("FSK_POWER = "); Serial.println(FSK_POWER, DEC);
  Serial.print("CW_POWER = "); Serial.println(CW_POWER, DEC);
  Serial.print("TX_FD = "); Serial.println(TX_FD, 2);
  Serial.print("RX_FD = "); Serial.println(RX_FD, 2);
  Serial.print("RX_Bandwidth = "); Serial.println(RX_Bandwidth, DEC);
  Serial.print("Data_Rate = "); Serial.println(Data_Rate, 2);
  if( AFC != 0 )
  {
    Serial.println("AFC = ON");
    Serial.print("AFC_BW = "); Serial.println(AFC_BW, 2);
  }
  else Serial.println("AFC = OFF");

  radio.setBitRate(Data_Rate);  //4.8         
  radio.setFrequencyDeviation(RX_FD); // 1.2
  radio.setRxBandwidth(RX_Bandwidth);     //25
  radio.receiveDirect();
  
  for(int q = 0; q<5; q++)                      
  {
    for( int i =0; i<9; i++)
    {
      EEPROM.update( i+10*q+100, EEPROM_WRITE_BUFFER[i] );
    } 

    Serial.print("Reading TX frequency related section = ");
    Serial.print(q, DEC);
    Serial.print(" | ");
    for( int i = 0; i<9; i++)
    {
      Serial.print( EEPROM.read(i+10*q+100), HEX );
      Serial.print(" ");
    }
    Serial.println();  
  }
  
}


void WRITE_RX_FREQUENCY_IN_EEPROM_BY_COMPIC()
{
  // #T456.3768#
  uint16_t ROUND_PART = ( (uint16_t)COMP_CW_DATA_ARRAY[2] )*100  + COMP_CW_DATA_ARRAY[3]*10  + COMP_CW_DATA_ARRAY[4];
  uint16_t DEC_PART   = ( (uint16_t)COMP_CW_DATA_ARRAY[6] )*1000 + ( (uint16_t)COMP_CW_DATA_ARRAY[7] )*100 + COMP_CW_DATA_ARRAY[8]*10 + COMP_CW_DATA_ARRAY[9];               
                   
  Serial.print(ROUND_PART,HEX); Serial.println(DEC_PART,HEX);

  RX_FREQUENCY = (float)ROUND_PART + ((float)DEC_PART) / 10000;
  GFSK_DIRECT_MODE_RX( RX_FREQUENCY, Data_Rate, RX_FD, RX_Bandwidth );  //435.3064 ___ 435.3079          newboard   
  Serial.print("RX frequency changed to - ");
  Serial.println(RX_FREQUENCY, 4);
  
  EEPROM_WRITE_BUFFER[0] = (uint8_t)((ROUND_PART>>8)&0x00FF) ;  
  EEPROM_WRITE_BUFFER[1] = (uint8_t)( ROUND_PART    &0x00FF) ;  
  EEPROM_WRITE_BUFFER[2] = (uint8_t)((DEC_PART  >>8)&0x00FF) ;
  EEPROM_WRITE_BUFFER[3] = (uint8_t)( DEC_PART      &0x00FF) ;
  
  uint16_t CRC_VAL = CRC_CALC(EEPROM_WRITE_BUFFER,4);
  EEPROM_WRITE_BUFFER[4] = (uint8_t)((CRC_VAL>>8)&0x00FF);
  EEPROM_WRITE_BUFFER[5] = (uint8_t)( CRC_VAL &0x00FF )  ;
  
  for(int q = 0; q<5; q++)                      
  {
    for( int i =0; i<6; i++)
    {
      EEPROM.update( i+10*q, EEPROM_WRITE_BUFFER[i] );
    } 

    Serial.print("Reading RX frequency related section = ");
    Serial.print(q, DEC);
    Serial.print(" | ");
    for( int i = 0; i<6; i++)
    {
      Serial.print( EEPROM.read(i+10*q), HEX );
      Serial.print(" ");
    }
    Serial.println();  
  }
}


void WRITE_TX_FREQUENCY_IN_EEPROM_BY_COMPIC()
{
    // #T456.3768#
    uint16_t ROUND_PART = ( (uint16_t)COMP_CW_DATA_ARRAY[2] )*100  + COMP_CW_DATA_ARRAY[3]*10  + COMP_CW_DATA_ARRAY[4];
    uint16_t DEC_PART   = ( (uint16_t)COMP_CW_DATA_ARRAY[6] )*1000 + ( (uint16_t)COMP_CW_DATA_ARRAY[7] )*100 + COMP_CW_DATA_ARRAY[8]*10 + COMP_CW_DATA_ARRAY[9];               
                    
    Serial.print(ROUND_PART,HEX); Serial.println(DEC_PART,HEX);

    TX_FREQUENCY = float(ROUND_PART) + (float(DEC_PART)) / 10000;
    //radio.setFrequency(TX_FREQUENCY); no need
    Serial.print("TX frequency changed to - ");
    Serial.println(TX_FREQUENCY, 4);
    
    EEPROM_WRITE_BUFFER[0] = (uint8_t)((ROUND_PART>>8)&0x00FF) ;  
    EEPROM_WRITE_BUFFER[1] = (uint8_t)( ROUND_PART    &0x00FF) ;  
    EEPROM_WRITE_BUFFER[2] = (uint8_t)((DEC_PART  >>8)&0x00FF) ;
    EEPROM_WRITE_BUFFER[3] = (uint8_t)( DEC_PART      &0x00FF) ;
    
    uint16_t CRC_VAL = CRC_CALC(EEPROM_WRITE_BUFFER,4);
    EEPROM_WRITE_BUFFER[4] = (uint8_t)((CRC_VAL>>8)&0x00FF);
    EEPROM_WRITE_BUFFER[5] = (uint8_t)( CRC_VAL &0x00FF )  ;
    
    for(int q = 0; q<5; q++)                      
    {
      for( int i =0; i<6; i++)
      {
        EEPROM.update( i+10*q+50, EEPROM_WRITE_BUFFER[i] );
      } 

      Serial.print("Reading TX frequency related section = ");
      Serial.print(q, DEC);
      Serial.print(" | ");
      for( int i = 0; i<6; i++)
      {
        Serial.print( EEPROM.read(i+10*q+50), HEX );
        Serial.print(" ");
      }
      Serial.println();  
    }
}

//gjgujgjghjgbjhgbjmbj mb jhmnb jhnb jhn
void LOAD_TRANCEIVER_SETTINGS()
{ 
  int CRC_MATCHED_FLAG = 0x00;
  
  for(int q = 0; q<5; q++)                      
  {
    for( int i =0; i<=8; i++)
    {
      EEPROM_READ_BUFFER[i] = EEPROM.read( i+10*q+100 );
    } 

    Serial.print("Transmitter setting data = ");
    Serial.print(q, DEC);
    Serial.print(" | ");
    for( int i = 0; i<=8; i++)
    {
      Serial.print( EEPROM_READ_BUFFER[i], HEX );
      Serial.print(" ");
    }
    Serial.println();  

    uint16_t CRCVAL = CRC_CALC(EEPROM_READ_BUFFER, 7);
    uint8_t C1 = (uint8_t)((CRCVAL>>8)&0x00FF)  ;
    uint8_t C2 = (uint8_t)( CRCVAL    &0x00FF)  ;
    
    if( (EEPROM_READ_BUFFER[7] == C1) && (EEPROM_READ_BUFFER[8] == C2)  )
    {
      //Serial.println("CRC matched");

      FSK_POWER    = EEPROM_READ_BUFFER[0];
      CW_POWER     = EEPROM_READ_BUFFER[1];
      TX_FD        = ((float)(EEPROM_READ_BUFFER[2])) /10; 
      RX_FD        = ((float)(EEPROM_READ_BUFFER[3])) /10; 
      RX_Bandwidth = ((float)(EEPROM_READ_BUFFER[4])) /10;
      Data_Rate    = ((float)(EEPROM_READ_BUFFER[5])) /10;
      if( EEPROM_READ_BUFFER[6] != 0 )
      {
        AFC = 1;
        AFC_BW = ((float)EEPROM_READ_BUFFER[6])/10;  
      }
      else AFC = 0;
  
      Serial.print("FSK_POWER = "); Serial.println(FSK_POWER, DEC);
      Serial.print("CW_POWER = "); Serial.println(CW_POWER, DEC);
      Serial.print("TX_FD = "); Serial.println(TX_FD, 2);
      Serial.print("RX_FD = "); Serial.println(RX_FD, 2);
      Serial.print("RX_Bandwidth = "); Serial.println(RX_Bandwidth, DEC);
      Serial.print("Data_Rate = "); Serial.println(Data_Rate, 2);
      if( AFC != 0 )
      {
        Serial.println("AFC = ON");
        Serial.print("AFC_BW = "); Serial.println(AFC_BW, 2);
      }
      else Serial.println("AFC = OFF");

      CRC_MATCHED_FLAG = 0x96;
      break;
    }

    else Serial.println("CRC not matched trying again");
  }

  if( CRC_MATCHED_FLAG == 0x00)
  {
    Serial.println("CRC not matched, default setting set");
    
    Serial.print("FSK_POWER = "); Serial.println(FSK_POWER, DEC);
    Serial.print("CW_POWER = "); Serial.println(CW_POWER, DEC);
    Serial.print("TX_FD = "); Serial.println(TX_FD, 2);
    Serial.print("RX_FD = "); Serial.println(RX_FD, 2);
    Serial.print("RX_Bandwidth = "); Serial.println(RX_Bandwidth, DEC);
    Serial.print("Data_Rate = "); Serial.println(Data_Rate, 2);
    if( AFC != 0 )
    {
      Serial.print("AFC = ON");
      Serial.print("AFC_BW = "); Serial.println(AFC_BW, 2);
    }
    else Serial.print("AFC = OFF");
  }
}
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//________________________________________________________________________
void CHECK_SETTINGS_COMMANDS()
{
  if(Serial.available())
  {
    delay(20);
    int size_ = Serial.available();
    for(int j=0; j<size_; j++)
    {
      SERIAL_BUFFER[j] = Serial.read();
    }  
    Serial.println(); 
    
    Serial.print("Reseceived command from PC > ");
    for(int i=0; i<size_; i++)
    {
      Serial.write(SERIAL_BUFFER[i]);
      Serial.print(" ");
    }
    Serial.println();
    while( Serial.available() ) Serial.read();
  }

  if( (SERIAL_BUFFER[0] == 0x23) && ( SERIAL_BUFFER[24] == 0x23 ) ) //*#
  {
    Serial.println("Setting command");
    WRITE_TRANCEIVER_SETTINGS_IN_EEPROM();

    for( int i = 0; i<25; i++) SERIAL_BUFFER[i] = 0;
  }

  else if( (SERIAL_BUFFER[0] == 0x23) && ( SERIAL_BUFFER[10] == 0x23 ) )
  {
    WRITE_RX_FREQUENCY_IN_EEPROM();
    WRITE_TX_FREQUENCY_IN_EEPROM();

    for( int i = 0; i<25; i++) SERIAL_BUFFER[i] = 0;
  }
}
volatile uint8_t dec = 0 ;

void freq_correction(int val)
{ 
    counter++;
    if( counter > val)
    {
      counter = 0;
      if( AFC == 1 )
      {
        radio.SPIsetRegValue(0x0D, SX127X_RESTART_RX_WITH_PLL_LOCK , 5, 5, 2, 0xFF);
      }
      CHECK_SETTINGS_COMMANDS();
      MLC++;
    }
    if(MLC > 60)
    {
      Serial.println(dec++, DEC);
      //Serial.println(radio.SPIreadRegister(0x0C), BIN);
      MLC = 0;
    }   
}

unsigned short AX25_computeCRC(uint8_t buffer[], uint16_t size_frame) 
{
  unsigned int i, j;
  unsigned short shiftRegister, outBit;
  char byte;

  // The last flag and the 2 bytes for FCS are removed.
  size_frame = size_frame - 3;

  // Initialization of the Shift Register to 0xFFFF
  shiftRegister = 0xFFFF;

  for(i=1 ; i<size_frame; i++)   // The first flag is not calculated so i=1.
  {
    byte = buffer[i];

    for(j=0; j<8; j++) 
    {
      outBit = shiftRegister & 0x0001;
      shiftRegister >>= 0x01;  // Shift the register to the right.

      if(outBit != (byte & 0x01)) 
      {
        shiftRegister ^= 0x8408;  // Mirrored polynom.
        byte >>= 0x01;
        continue;
      }
      byte >>= 0x01;
    }
  }
  return shiftRegister^ 0xFFFF;  // Final XOR.
}

void AX25_putCRC(uint8_t *frame, unsigned short size_frame) 
{
  unsigned short crc;

  // FCS calculation.
  crc = AX25_computeCRC(frame, size_frame); 

  // Put the FCS in the right place with the 15th bit to be sent first.
  frame[size_frame - 3] = (crc & 0xff);
  frame[size_frame - 2] = ((crc >> 8) & 0xff);
}


//_______________________________________________________________________________________
#include "c_G3RUH.h"
//#include "ZZZ.h"
#include "g_CW_Fun.h"
#include "e_TRX_Fun.h"
