// declaration of variables
uint8_t   TXbit_to_FModulation;
uint8_t   PrevsBit;
uint8_t   TX_Mode;
uint32_t  Shift_Register;
uint8_t   Nof_bit1_Counter;
uint16_t  Flags_to_send; 
uint16_t  Byte_Counter; 
uint8_t   Bit_Counter;
uint16_t  Frame_Length;
uint8_t   Bitstuff_Status;
uint8_t   transmission;

//_______________________________________________________________________
unsigned int TX_DELAY   =    60;   // Number of flags to be sent before the frame.
#define TX_TAIL              20    

// Tx Modes
#define TX_OFF               0x00   // Off mode (Tx off).
#define TX_DELAY_FLAG        0x01   // Synchronization mode (sending flags).
#define TX_DATA_MODE         0x02   // Data transmission mode.
#define TX_TAIL_MODE         0x03   // Tail mode (send flags after the frame)

// Rx Modes
#define RX_OFF               0x00  // Receiver is off.
#define RX_FREQ_SYNC_MODE    0x01  // First flag detection mode.
#define RX_FLAGS_MODE        0x02  // Ignoring sync flags.
#define RX_DATA_MODE         0x03  // Data decoder mode.


int NRZI_current_state; //
uint8_t firstXorScrambler;

void AX25_txInitCfg() 
{
  TX_Mode              = TX_DELAY_FLAG ;
  Flags_to_send         = TX_DELAY      ;
  TXbit_to_FModulation = 0             ;
  PrevsBit             = 0             ;
  //Shift_Register       = 0x0000      ;
  Nof_bit1_Counter     = 0             ;
  Byte_Counter         = 1             ; 
  Bit_Counter          = 0             ;
  Frame_Length         = TXAC          ;
}

uint8_t NRZI_encoding(uint8_t bit)
{
  int encoded_bit;
  if(bit == 0)    // Last bit status changes 
  {
    encoded_bit    = !PrevsBit    ;   
    PrevsBit       = encoded_bit ;
    Nof_bit1_Counter  = 0;   
  }
  else            // Last bit remains same
  {
    encoded_bit  = PrevsBit    ;
    PrevsBit     = encoded_bit ;
    Nof_bit1_Counter++;             // If bit=1 increment Nof_bit1_Counter for bit stuffing.
  }
  return encoded_bit;
}

void process_txBit(uint8_t data_bit)
{
  // bit17 XOR bit12.
  TXbit_to_FModulation = NRZI_encoding(data_bit) ^ ( bitRead(Shift_Register,11) ^ bitRead(Shift_Register,16) );
  
  Shift_Register <<= 1;  // Shifting the shift register one bit to left
  
  if(TXbit_to_FModulation) bitSet  (Shift_Register, 0);
}


char CHECK_BIT_STUFFING(void) 
{
  if(Nof_bit1_Counter >= 5) // If we have 5 ones -> stuff a 0.
  {  
    // bit17 XOR bit12.
    firstXorScrambler = bitRead(Shift_Register,11) ^ bitRead(Shift_Register,16) ;
    
    // Add zero bit and NRZI encoding
    TXbit_to_FModulation = NRZI_encoding(0) ^ firstXorScrambler;   
    
    Shift_Register <<= 1;  // Shifting the shift register one bit to left
    
    if(TXbit_to_FModulation) bitSet(Shift_Register, 0);
    
    Nof_bit1_Counter = 0;
    return 1;
  }
  return 0;
}

 
char Prepare_NextBit_To_Send(uint8_t *buffer) 
{
  if(TX_Mode == TX_DELAY_FLAG) 
  { 
    process_txBit( bitRead(0x7E, Bit_Counter) );  // take the bit and encode it.
    Bit_Counter++;
    if(Bit_Counter > 7) 
    {
      Bit_Counter = 0 ;  
      Flags_to_send-- ; 
      if(Flags_to_send == 0) 
      {  
          TX_Mode = TX_DATA_MODE;  // The flags are sent : go to TX_DATA_MODE.
          return 1;
      }
    }
    return 1;
  }
  
  else if(TX_Mode == TX_DATA_MODE)
  {
    if(CHECK_BIT_STUFFING()) return 1;
    
    process_txBit( bitRead( buffer[Byte_Counter], Bit_Counter) );  // Fetch the bit and encode it.

    Bit_Counter++;
    if(Bit_Counter > 7) 
    {
      Bit_Counter = 0;  // A byte is sent. Reset the Bit_Counter.  
      if(Byte_Counter == Frame_Length-2) // Check if all the data are sent.
      {  
        TX_Mode = TX_TAIL_MODE;  
        Flags_to_send = TX_TAIL;
      }
      Byte_Counter++;  // Next byte to send.
    }
    return 1;
  }

  else if(TX_Mode == TX_TAIL_MODE) 
  { 
    process_txBit( bitRead(0x7E, Bit_Counter) );  // Fetch the bit and encode it.

    Bit_Counter++;
    if(Bit_Counter > 7) 
    {
      Bit_Counter = 0;       // A byte is sent. Reset the Bit_Counter.  
      Flags_to_send--;
      if(Flags_to_send == 0) // Check if there are still flags to send.
      {  
          TX_Mode = TX_OFF;  // The flags are sent : go to TX_DATA_MODE.
          return 0;
      }
    }
    return 1;
  }
}

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

void INITIALIZE_RX_PARAMETERS() 
{
  rxMode           = RX_FREQ_SYNC_MODE ;
  Nof_bit1_Counter = 0                 ;
  PrevsBit         = 1                 ;
  Byte_Counter     = 1                 ;
  Bit_Counter      = 0                 ;
  Bitstuff_Status  = 0                 ;
}

char Extract_RxBit(char bit) 
{
  // Descramble the bit.
  char RcvdBit = bit ^ ( bitRead(Shift_Register,11) ^ bitRead(Shift_Register,16) );

  // NRZI decoding.
  char decodedBit = (RcvdBit == PrevsBit) ? 0x01 : 0x00;

  // Refresh the previous bit received.
  PrevsBit = RcvdBit;

  // Shift the register to the left.
  Shift_Register = (Shift_Register << 1) | bit;

  return decodedBit;
}

uint32_t Sync_Word;


uint8_t Process_RX_Bit(uint8_t *RX_Bffr, uint8_t incoming_bit) 
{
  int rxbit = Extract_RxBit(incoming_bit) ;

  if(rxMode == RX_FREQ_SYNC_MODE) 
  {
    Sync_Word >>= 1;                                // Shift to the right.
    if( rxbit ) bitSet(Sync_Word, 23);              // put the bit at 7th bit possition.
    
    if( Sync_Word == 0x7E7E7E )                     // Check if we have 3 flags (sync word).
    {                 
      rxMode = RX_FLAGS_MODE;                       // If so, go to ignoring flags mode.
      return 1;
    }
    freq_correction(AFC_BITS);
    IWatchdog.reload();
    return 1;
  }

  else if(rxMode == RX_FLAGS_MODE) 
  {
    RX_Bffr[Byte_Counter] >>= 1;                          // Shift to the right.
    if( rxbit ) bitSet(RX_Bffr[Byte_Counter], 7);         // put the bit at 7th bit possition.

    Bit_Counter++;                                        // Increment the bit counter.
    if(Bit_Counter > 7)                                   // Check if we have a byte.
    {  
      Bit_Counter = 0;
      if(RX_Bffr[Byte_Counter] != 0x7E)                    // If the byte is not a flag.
      { 
        rxMode = RX_DATA_MODE;  // go to Rx Data mode. 
        Byte_Counter++;
      }          
    }
    return 1;
  }
  
  else if(rxMode == RX_DATA_MODE) 
  {
    if(Bitstuff_Status == 0)
    { 
      RX_Bffr[Byte_Counter] >>= 1 ;
      if(rxbit == 1)                                   
      {  
        bitSet(RX_Bffr[Byte_Counter], 7);               // Stock the bit.
        Nof_bit1_Counter++;                               // Count up every 1.
        if(Nof_bit1_Counter >= 5) Bitstuff_Status = 1;      // Check the next bit for bit stuffing.
      }
      else                                             // We have a 0.
      {  
        bitClear(RX_Bffr[Byte_Counter], 7);
        Nof_bit1_Counter = 0;                             // Clear bit set counter.
      }
    }
        
    else 
    {
      if(rxbit == 0)
      {
        Bitstuff_Status  = 0;                      // Clear the bit stuffing indicator.
        Nof_bit1_Counter = 0;                      // Clear the bit set counter.
        return 1;                                    // Stuffed bit detected.
      }
      else                                           // If it is not a stuffed bit it is a flag.
      { 
        RX_Bffr[Byte_Counter] = 0x7E; 
        rxMode = RX_OFF;                             // End of the frame go to off mode.
        return 0;
      }
    }

    Bit_Counter++;                                    // Increment the bit counter.
    if(Bit_Counter > 7)                               // Check if we have a byte.
    { 
      Bit_Counter = 0;
      Byte_Counter++;
    }
    return 1;  
  }
}
